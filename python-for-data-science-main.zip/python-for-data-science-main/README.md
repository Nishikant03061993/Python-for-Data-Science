Note: The dataset for project #4 couldn't be uploaded to GitHub, but you can download it here: https://www.kaggle.com/datasets/lakshmi25npathi/imdb-dataset-of-50k-movie-reviews

🔥 Download my Python for Data Science Cheat Sheet (Free PDF): https://artificialcorner.com/p/redeem-my-udemy-courses-for-free

🇪🇸 This course is also available in Spanish: https://youtu.be/Rgag-Clu5L4
